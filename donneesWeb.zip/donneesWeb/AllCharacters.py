import os,sys

allCharacters = '<?xml version="1.0" encoding="UTF-8"?><?xml-model href="Characters.rnc" type="application/relax-ng-compact-syntax"?><Characters><DC>'

for char in ['Batman','Aquaman','Superman','The_Flash','Green_Arrow','Martian_Manhunter','Green_Lantern']:
	file = open(char+'toXml.xml')
	#print type(file)
	allCharacters += file.read()#open(char+'toXml.xml')

allCharacters+='</DC><Marvel></Marvel></Characters>'

f = open('allCharacters.xml','w')
f.write(allCharacters)
f.close()
import os, sys
import urllib2
from bs4 import BeautifulSoup

## Dictionaries of Heroes->urls

dict = {'Batman': 'http://dc.wikia.com/wiki/Batman_%28Bruce_Wayne%29',
		'Aquaman': 'http://dc.wikia.com/wiki/Orin_%28New_Earth%29',
		'Superman': 'http://dc.wikia.com/wiki/Superman_%28Clark_Kent%29',
		'The_Flash': 'http://dc.wikia.com/wiki/Flash_%28Barry_Allen%29',
		'Green_Arrow': 'http://dc.wikia.com/wiki/Green_Arrow_%28Oliver_Queen%29',
		'Martian_Manhunter':'http://dc.wikia.com/wiki/J%27onn_J%27onzz_%28New_Earth%29',
		'Green_Lantern': 'http://dc.wikia.com/wiki/Green_Lantern_%28Hal_Jordan%29'
		}

input = sys.argv[1]
url = dict[input]

print 'input:'+input

response = urllib2.urlopen(url)
html = response.read()
#input = 'Aquaman'

#soup = BeautifulSoup(open(url+'.html'),'lxml')

soup = BeautifulSoup(html,'lxml')

asides = soup.find_all('aside')

f = open(input+'_short.html', 'w')
textHTML = asides[0].prettify().encode('utf-8')
f.write(textHTML)
f.close()
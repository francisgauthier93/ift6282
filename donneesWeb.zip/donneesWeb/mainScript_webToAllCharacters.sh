#!/bin/bash

#names=(Batman Aquaman Superman)

#
for i in Batman Aquaman Superman The_Flash Green_Arrow Martian_Manhunter Green_Lantern; do
	python initFileReader.py $i

	short="_short.html"
	shortFile=$i$short
	#echo $shortFile
	sed -i 's|<a[^>]\+>|<a>|g' $shortFile #remove href
	sed -i 's#<a[^>]*>##g' $shortFile     #remove a tags
	sed -i 's#</a[^>]*>##g' $shortFile	  #remove a end tags
	sed -i 's#<span[^>]*>##g' $shortFile  #remove span tags   
	sed -i 's#</span[^>]*>##g' $shortFile #remove span end tags
	sed -i 's#<br/>##g' $shortFile	      #remove break lines
	sed -i 's#<i>##g' $shortFile	      #remove i tags 
	sed -i 's#</i>##g' $shortFile	      #remove i end tags
	#sed -i 's#<b>##g' $shortFile	      #remove b tags 
	#sed -i 's#</b>##g' $shortFile	      #remove b end tags
	
	python soupToXml.py $i
done

python AllCharacters.py
import os, sys, re
from bs4 import BeautifulSoup

input = sys.argv[1]

soup_short = BeautifulSoup(open(input+'_short.html'),'lxml')

## A few functions

def stripInfo(strg):
	return ' '.join(strg.split())

def find_nextStr(soupe,strg):
	h3s = soupe.find_all('h3');
	for i in range(len(h3s)):
		#print h3s[i].string
		stripped = stripInfo(h3s[i].string)
		#print stripped 
		if stripped==strg:
			taaa = 0;
			for sibling in h3s[i].next_siblings:
				if sibling!='\n':# and sibling!='None':
					#print sibling
					answer = ' '.join(sibling.string.split())
					return re.split("\s,\s|\s;\s", answer)

def findS(str,tag=False):
	if(not tag):
		return find_nextStr(soup_short,str)[0];
	else:
		liste = find_nextStr(soup_short,str)
		out =''
		for i in range(len(liste)):
			out+='<'+tag+'>'+liste[i]+'</'+tag+'>'
		return out

##Get informations

rN = findS('Real Name');
cA = findS('Current Alias');
try:
	als = findS('Aliases','alias');
except TypeError:
	als = None
rel = findS('Relatives','relative')
aff = findS('Affiliation','group')
bop = findS('Base Of Operations','location')
alig = findS('Alignment')
iden = findS('Identity')
try:
	citiz = findS('Citizenship')
except TypeError:
	citiz = None
mar = findS('Marital Status')
occ = findS('Occupation')

try:
	educ = findS('Education')
except TypeError:
	educ = None

gend = findS('Gender')
height = findS('Height')
#height = '6\'1"'
weight = findS('Weight')
eyes = findS('Eyes')
hair = findS('Hair')

univ = findS('Universe','location')

try:
	pob = findS('Place of Birth', 'location')
except TypeError:
	pob = None
creat = findS('Creators','creator')

btag = soup_short.find_all('b')
for string in btag[0].stripped_strings:
	firAp = string
#lasAp = 'last'

##Begin Output

output = '<character>\n<superHeroAlias>\n'+input+'</superHeroAlias>\n<realName>'+rN+'</realName>'
if als is not None:
	output +='<otherAliases>'+als+'</otherAliases>'
output +='<relatives>'+rel+'</relatives>'
output +='<affiliation>'+aff+'</affiliation>'
output +='<baseOfOperation>'+bop+'</baseOfOperation>'
output +='<status>\n<alignment>'+alig+'</alignment>\n<identity>'+iden+'</identity>'
if citiz is not None:
	output +='<citizenship>'+citiz+'</citizenship>'
output+='\n<maritalStatus>'+mar+'</maritalStatus>'
output +='<occupation>'+occ+'</occupation>\n'
if educ!=None:
	output+='<education>'+educ+'</education>\n'
output +='</status><characteristics>\n<gender>'+gend+'</gender>\n<height>'+height+'</height>'
output +='<weight>'+weight+'</weight>\n<eyes>'+eyes+'</eyes>\n<hair>'+hair+'</hair>\n</characteristics>'
output +='<origin>\n<universe>'+univ+'</universe>\n'
if pob is not None:
	output+='<placeOfBirth>'+pob+'</placeOfBirth>'
output +='<creators>'+creat+'</creators>\n</origin>\n<firstAppearance>\n<title>'+firAp+'</title>\n</firstAppearance>'
#output +='<lastApperance>'+lasAp+'</lastApperance>'
output +='</character>'

#Output the character file to XML
fo = open(input+'toXml.xml','w')
output = output.encode('utf-8')
fo.write(output)
fo.close()
